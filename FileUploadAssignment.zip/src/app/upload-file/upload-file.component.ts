import { Component, OnInit } from '@angular/core';
import { CSVModel } from '../model/csv-model';
import { HttpClient, HttpEventType } from '@angular/common/http';

@Component({
  selector: 'app-upload-file',
  templateUrl: './upload-file.component.html',
  styleUrls: ['./upload-file.component.css']
})
export class UploadFileComponent implements OnInit {

  records: CSVModel[] = [];
  displayData = false;
  headersRow;
  timeout: any;
  fileUploadProgress;
  uploadedFilesNames = [];

  constructor(private http: HttpClient) { }

  ngOnInit() {
  }

  /**
   * Allows the user to select a file and validates it based on the headers
   * @param $event Selected File details
   */
  async uploadListener($event: any) {
    const reader = new FileReader();
    const files = $event.srcElement.files;

    if (await this.isValidCSVFile(files[0])) {
    this.uploadedFilesNames.push({file: files[0], fileName: files[0].name, status: 'Pending'});

    reader.readAsText($event.target.files[0]);
    reader.onload = async () => {
      const csvData = reader.result;
      const csvRecordsArray = (<string>csvData).split(/\r\n|\n/);

      const headerArray = ['Prod', 'Cust', 'Period', 'Quantity'];
      this.headersRow = await this.getHeaderArray(csvRecordsArray);

      let valid = true;
      headerArray.forEach(header => {
        if (!this.headersRow.includes(header.toUpperCase())) {
          valid =  false;
        }
      });
      this.displayData = true;

      if (valid) {
        this.uploadFileToServer($event.target.files[0]);
      } else {
        this.uploadedFilesNames.forEach(fileData => {
          if (fileData.file === files[0]) {
          fileData.status = 'Could not upload as required headers are not present';
        }});
      }

    };

    reader.onerror = function () {
      console.log('error occured while reading file!');
    };
  } else {
    this.fileReset();
  }
  }

  /**
   * Resets the file if error occurs
   */
  fileReset() {
    this.records = [];
  }

  /**
   * Generates the header array from the column headings of the file
   * @param csvRecordsArr Rows of the file
   */
  getHeaderArray(csvRecordsArr: any) {
    const headers = (<string>csvRecordsArr[0]).split(',');
    const headerArray = [];
    for (let j = 0; j < headers.length; j++) {
      headerArray.push(headers[j]);
    }
    return headerArray;
  }

  /**
   * Checks whether the file is selcted and of format csv
   * @param file Selected file
   */
  isValidCSVFile(file: any) {
    if (file !== undefined) {
      return file.name.endsWith('.csv');
    }
    return false;
  }


  /**
   * Uploads the file to server
   * @param csvData File to be uploaded to server
   */
  uploadFileToServer(csvData) {
    const formData = new FormData();
    formData.append('filesUploaded', csvData);
    formData.append('category', 'file');
    formData.append('comments', '0');
    this.fileUploadProgress = 0;

    this.http.post('https://srv-file14.gofile.io/upload', formData, {
      reportProgress: true,
      observe: 'events'
    })
    .subscribe(events => {
      if (events.type === HttpEventType.UploadProgress) {
        this.fileUploadProgress = Math.round(events.loaded / events.total * 100);
        console.log(this.fileUploadProgress);
      } else if (events.type === HttpEventType.Response) {
        this.fileUploadProgress = 0;
        this.uploadedFilesNames.forEach(fileData => {
          if (fileData.file === csvData) {
          fileData.status = 'Completed with status ' + JSON.parse(JSON.stringify(events.body)).status;
        }});
      }
    });
  }


}
