export class CSVModel {
    prod: string;
    cost: string;
    period: string;
    quantity: string;
}
